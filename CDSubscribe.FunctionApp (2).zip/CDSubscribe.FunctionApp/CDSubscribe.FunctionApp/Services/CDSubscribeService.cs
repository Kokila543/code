﻿
using CDSubscribe.FunctionApp.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDSubscribe.FunctionApp.Services
{
    public class CDSubscribeService : ICDSubscribeService
    {
        private readonly ISubscriptionRepository _repository;
        private readonly ILogger<CDSubscribeService> _logger;

        public CDSubscribeService(
            ISubscriptionRepository repository,
            ILogger<CDSubscribeService> logger)
        {
            _repository = repository;
            _logger = logger;
        }

        public async Task ProcessAsync()
        {
            _logger.LogInformation("Fetching pending subscriptions...");

            var subscriptions = await _repository.GetPendingSubscriptionsAsync();

            if (!subscriptions.Any())
            {
                _logger.LogInformation("No pending subscriptions found.");
                return;
            }

            foreach (var subscription in subscriptions)
            {
                _logger.LogInformation("Processing subscription {Id}", subscription.Id);

                subscription.MarkProcessed();

                await _repository.UpdateAsync(subscription);
            }

            _logger.LogInformation("Processing completed.");
        }
    }

}

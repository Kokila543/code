﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDSubscribe.FunctionApp.Interfaces
{
    public interface ICDSubscribeService
    {
        Task ProcessAsync();
    }

}

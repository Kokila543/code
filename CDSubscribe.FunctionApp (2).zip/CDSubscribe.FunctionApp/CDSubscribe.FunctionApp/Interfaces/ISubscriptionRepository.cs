﻿using CDSubscribe.FunctionApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDSubscribe.FunctionApp.Interfaces
{
    public interface ISubscriptionRepository
    {
        Task<List<Subscription>> GetPendingSubscriptionsAsync();
        Task UpdateAsync(Subscription subscription);
    }

}

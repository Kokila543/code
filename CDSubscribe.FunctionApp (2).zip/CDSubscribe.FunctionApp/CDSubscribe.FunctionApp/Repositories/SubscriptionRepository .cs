﻿using CDSubscribe.FunctionApp.Data;
using CDSubscribe.FunctionApp.Interfaces;
using CDSubscribe.FunctionApp.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDSubscribe.FunctionApp.Repositories
{
    public class SubscriptionRepository : ISubscriptionRepository
    {
        private readonly AppDbContext _context;

        public SubscriptionRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Subscription>> GetPendingSubscriptionsAsync()
        {
            return await _context.Subscriptions
                .Where(x => !x.IsProcessed)
                .ToListAsync();
        }

        public async Task UpdateAsync(Subscription subscription)
        {
            _context.Subscriptions.Update(subscription);
            await _context.SaveChangesAsync();
        }
    }

}

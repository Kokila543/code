﻿namespace CDSubscribe.FunctionApp.Models;

public class Subscription
{
    public int Id { get; set; }
    public string Email { get; set; } = string.Empty;
    public bool IsProcessed { get; set; }
    public DateTime CreatedDate { get; set; }

    public void MarkProcessed()
    {
        IsProcessed = true;
    }
}

﻿
using CDSubscribe.FunctionApp.Interfaces;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CDSubscribe.FunctionApp.Functions
{
    public class CDSubscribeTimer
    {
        private readonly ICDSubscribeService _service;
        private readonly ILogger<CDSubscribeTimer> _logger;

        public CDSubscribeTimer(ICDSubscribeService service, ILogger<CDSubscribeTimer> logger)
        {
            _service = service;
            _logger = logger;
        }

        [Function("CDSubscribeTimer")]
        public async Task Run([TimerTrigger("*/1 * * * * *")] TimerInfo timer)
        //[TimerTrigger("%CDSubscribeSchedule%")] TimerInfo timer)
        {
            _logger.LogInformation("Timer triggered at {time}", DateTime.UtcNow);

            await _service.ProcessAsync();

            _logger.LogInformation("Timer execution finished.");
        }
    }

}
